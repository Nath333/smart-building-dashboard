# Database Operations Logging Guide

## Overview
Comprehensive logging has been added to track all normalized database operations with detailed performance metrics, success/error reporting, and dual-write monitoring.

---

## Logging System Components

### 1. **Logger Utility**
**File:** `database/utils/logger.js`

Centralized logging system with specialized methods for:
- Query operations (SELECT, INSERT, UPDATE, DELETE)
- Adapter conversions (flat ↔ normalized)
- Performance tracking (execution time)
- Dual-write operations monitoring
- Error reporting with stack traces

### 2. **Data Access Layer (DAL) Logging**
**File:** `database/dal/equipmentDAL.js`

All database operations now include:
- Query start/end logging
- Record counts
- Performance metrics
- Error details with context

### 3. **Adapter Layer Logging**
**File:** `database/adapters/formSqlAdapter.js`

Tracks:
- Conversion operations (normalized → flat, flat → normalized)
- Dual-write success/failure status
- Field counts
- Performance timing

---

## Log Output Examples

### GET Request (Fetching Data)

When frontend requests data via `/get-page2`:

```
📥 [POST] /get-page2 for site "site2" - Using NORMALIZED DB ✨
[2025-10-14T15:45:10.123Z] 📤 Adapter: Converting FROM normalized TO flat structure for site "site2"
[2025-10-14T15:45:10.125Z] 🔍 DB Query: SELECT on equipment_aerotherme + brands for site "site2" {}
[2025-10-14T15:45:10.145Z] ✅ DB Success: SELECT on equipment_aerotherme for site "site2" { equipment_records: 1, brand_records: 2 }
[2025-10-14T15:45:10.146Z] ⚡ Performance: getAerothermeData for "site2" took 21ms {}
[2025-10-14T15:45:10.150Z] 🔍 DB Query: SELECT on equipment_rooftop + brands for site "site2"
[2025-10-14T15:45:10.167Z] ✅ DB Success: SELECT on equipment_rooftop for site "site2" { equipment_records: 1, brand_records: 0 }
[2025-10-14T15:45:10.168Z] ⚡ Performance: getRooftopData for "site2" took 18ms {}
[2025-10-14T15:45:10.170Z] 🔍 DB Query: SELECT on equipment_climate + references for site "site2"
[2025-10-14T15:45:10.185Z] ✅ DB Success: SELECT on equipment_climate for site "site2" { equipment_records: 1, reference_records: 3 }
[2025-10-14T15:45:10.186Z] ⚡ Performance: getClimateData for "site2" took 16ms {}
[2025-10-14T15:45:10.188Z] 🔍 DB Query: SELECT on equipment_lighting for site "site2"
[2025-10-14T15:45:10.198Z] ✅ DB Success: SELECT on equipment_lighting for site "site2" { records: 1 }
[2025-10-14T15:45:10.199Z] ⚡ Performance: getLightingData for "site2" took 11ms {}
[2025-10-14T15:45:10.200Z] ✅ DB Success: CONVERT on normalized_to_flat for site "site2" { fields_generated: 125 }
[2025-10-14T15:45:10.201Z] ⚡ Performance: convertToFlatStructure for "site2" took 78ms { fields: 125 }
✅ Retrieved data from normalized tables for site "site2"
```

### SAVE Request (Saving Data)

When frontend saves data via `/save_page2`:

```
💾 [POST] /save_page2 for site "site2" - Using NORMALIZED DB ✨
[2025-10-14T15:46:15.234Z] 📥 Adapter: Converting FROM flat TO normalized structure for site "site2"
[2025-10-14T15:46:15.236Z] 🔍 DB Query: UPSERT on equipment_aerotherme + brands for site "site2" { nb_aerotherme: 5 }
[2025-10-14T15:46:15.298Z] ✅ DB Success: UPSERT on equipment_aerotherme for site "site2" { equipment_rows: 1, brands_saved: 3 }
[2025-10-14T15:46:15.299Z] ⚡ Performance: saveAerothermeData for "site2" took 63ms {}
[2025-10-14T15:46:15.301Z] 🔍 DB Query: UPSERT on equipment_rooftop + brands for site "site2"
[2025-10-14T15:46:15.345Z] ✅ DB Success: UPSERT on equipment_rooftop for site "site2" { equipment_rows: 1, brands_saved: 0 }
[2025-10-14T15:46:15.346Z] ⚡ Performance: saveRooftopData for "site2" took 45ms {}
[2025-10-14T15:46:15.348Z] 🔍 DB Query: UPSERT on equipment_climate + references for site "site2"
[2025-10-14T15:46:15.410Z] ✅ DB Success: UPSERT on equipment_climate for site "site2" { equipment_rows: 1, references_saved: 5 }
[2025-10-14T15:46:15.411Z] ⚡ Performance: saveClimateData for "site2" took 63ms {}
[2025-10-14T15:46:15.413Z] 🔍 DB Query: UPSERT on equipment_lighting for site "site2"
[2025-10-14T15:46:15.438Z] ✅ DB Success: UPSERT on equipment_lighting for site "site2" { equipment_rows: 1 }
[2025-10-14T15:46:15.439Z] ⚡ Performance: saveLightingData for "site2" took 26ms {}
[2025-10-14T15:46:15.501Z] 🔄 Dual-Write for site "site2":
  Legacy form_sql: ✅ Success
  Normalized tables: ✅ Success
[2025-10-14T15:46:15.502Z] ✓ Performance: saveToBothStructures for "site2" took 268ms {}
✅ Saved to NORMALIZED tables for site "site2"
```

### Error Scenario

When an error occurs:

```
💾 [POST] /save_page2 for site "invalid_site" - Using NORMALIZED DB ✨
[2025-10-14T15:47:20.123Z] 📥 Adapter: Converting FROM flat TO normalized structure for site "invalid_site"
[2025-10-14T15:47:20.125Z] 🔍 DB Query: UPSERT on equipment_aerotherme + brands for site "invalid_site" { nb_aerotherme: 3 }
[2025-10-14T15:47:20.145Z] ❌ DB Error: UPSERT on equipment_aerotherme for site "invalid_site"
  Error: Cannot add or update a child row: a foreign key constraint fails
  Code: ER_NO_REFERENCED_ROW_2
  SQL State: 23000
  Details: { nb_aerotherme: 3 }
  Stack: Error: Cannot add or update a child row...
    at Query.execute (...)
    at equipmentDAL.saveAerothermeData (...)
[2025-10-14T15:47:20.146Z] ❌ DB Error: SAVE on dual_write for site "invalid_site"
  Error: Cannot add or update a child row: a foreign key constraint fails
  Code: ER_NO_REFERENCED_ROW_2
  SQL State: 23000
  Details: { normalized_success: false, legacy_success: false }
❌ DB update error in NORMALIZED save:
- Error message: Cannot add or update a child row: a foreign key constraint fails
- Site: invalid_site
```

---

## Log Types & Meanings

### 🔍 Query Logs
Indicates database operation is starting:
- `SELECT` - Fetching data
- `UPSERT` - Insert or Update
- `DELETE` - Removing data
- `CONVERT` - Adapter transformation

### ✅ Success Logs
Operation completed successfully with metrics:
- Record counts
- Rows affected
- Fields processed

### ❌ Error Logs
Operation failed with detailed information:
- Error message
- SQL error code
- SQL state
- Context data
- Stack trace (first 3 lines)

### Performance Logs
Execution time tracking:
- ⚡ (< 100ms) - Fast operation
- ✓ (100-500ms) - Normal operation
- ⚠️ (> 500ms) - Slow operation (may need optimization)

### 📤 📥 Adapter Logs
Data conversion tracking:
- 📤 Normalized → Flat (for GET requests)
- 📥 Flat → Normalized (for SAVE requests)

### 🔄 Dual-Write Logs
Shows both legacy and normalized write status:
- Legacy form_sql: Success/Failed
- Normalized tables: Success/Failed

---

## Performance Metrics

### Typical Operation Times

| Operation | Expected Time | Details |
|-----------|--------------|---------|
| Single table SELECT | 10-30ms | One equipment table |
| Multiple table SELECT | 50-100ms | All equipment tables |
| Full conversion (flat) | 60-150ms | All tables + conversion |
| Single UPSERT | 20-50ms | One equipment + refs/brands |
| Full save (all equipment) | 150-300ms | All tables + dual-write |
| Dual-write complete | 200-400ms | Normalized + legacy |

### Performance Warning Thresholds

- ⚠️ **> 500ms for single operation**: Check query optimization
- ⚠️ **> 1000ms for full save**: Database connection pooling may be needed
- ⚠️ **Frequent slow queries**: Consider adding indexes

---

## Debugging with Logs

### Finding Specific Site Operations

Search logs for:
```bash
# All operations for a site
grep "site2" server-logs.txt

# Only errors for a site
grep "❌.*site2" server-logs.txt

# Performance issues
grep "⚠️.*Performance" server-logs.txt
```

### Tracking Request Flow

Example sequence for a save operation:
1. `💾 [POST] /save_page2` - Request received
2. `📥 Adapter: Converting FROM flat` - Starting conversion
3. `🔍 DB Query: UPSERT` - Database writes begin
4. `✅ DB Success: UPSERT` - Each table save completes
5. `🔄 Dual-Write` - Both writes complete
6. `✅ Saved to NORMALIZED tables` - Final confirmation

### Common Error Patterns

**Foreign Key Constraint Error:**
```
❌ DB Error: UPSERT on equipment_aerotherme
  Error: Cannot add or update a child row: a foreign key constraint fails
  Code: ER_NO_REFERENCED_ROW_2
```
**Cause:** Trying to save equipment for a site that doesn't exist in `sites` table
**Solution:** Ensure site exists in `sites` table first

**Connection Pool Exhausted:**
```
❌ DB Error: SELECT on equipment_aerotherme
  Error: Too many connections
  Code: ER_CON_COUNT_ERROR
```
**Cause:** Connection pool limit reached
**Solution:** Increase connection pool size in `database.js`

---

## Monitoring Production

### Key Metrics to Watch

1. **Success Rate**
   - Count of ✅ vs ❌ logs
   - Target: > 99.9% success

2. **Performance Trends**
   - Average operation time
   - 95th percentile response time
   - Target: < 200ms average

3. **Dual-Write Health**
   - Both writes succeeding
   - Target: 100% both successful

4. **Error Frequency**
   - Errors per hour
   - Target: < 1 per 1000 requests

### Setting Up Log Aggregation

For production, consider:
- **Winston** for structured logging
- **ELK Stack** (Elasticsearch, Logstash, Kibana) for log analysis
- **Datadog** or **New Relic** for APM
- **CloudWatch** (AWS) or **Stackdriver** (GCP) for cloud hosting

---

## Custom Log Filtering

### By Operation Type

```bash
# All SELECT operations
grep "DB Query: SELECT" server-logs.txt

# All UPSERT operations
grep "DB Query: UPSERT" server-logs.txt

# Conversion operations
grep "Adapter: Converting" server-logs.txt
```

### By Performance

```bash
# Fast operations (< 100ms)
grep "⚡ Performance" server-logs.txt

# Slow operations (> 500ms)
grep "⚠️ Performance" server-logs.txt
```

### By Table

```bash
# Aerotherme operations
grep "equipment_aerotherme" server-logs.txt

# Climate operations
grep "equipment_climate" server-logs.txt
```

---

## Log Rotation & Storage

### Recommended Setup

```javascript
// In server.js - add log rotation
import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';

const logger = winston.createLogger({
  transports: [
    new DailyRotateFile({
      filename: 'logs/database-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '14d' // Keep 14 days
    })
  ]
});
```

---

## Troubleshooting Checklist

### Logs Not Appearing

- [ ] Check server is running: `npm run server`
- [ ] Verify logger imported: Check `import logger from` statements
- [ ] Check console output redirection
- [ ] Verify background process output: Use `BashOutput` tool

### Performance Issues

- [ ] Check database connection pool size
- [ ] Verify indexes exist on foreign keys
- [ ] Check for N+1 query problems
- [ ] Monitor concurrent request count

### Data Inconsistencies

- [ ] Verify dual-write both successful
- [ ] Check foreign key constraints
- [ ] Validate transaction rollbacks working
- [ ] Ensure ACID properties maintained

---

## Summary

✅ **Comprehensive logging is now active** for all normalized database operations

**What's Logged:**
- Every database query (SELECT, INSERT, UPDATE, DELETE)
- All data conversions (flat ↔ normalized)
- Performance metrics for every operation
- Success/error status with details
- Dual-write operation results

**Benefits:**
- Real-time monitoring of database health
- Easy debugging with detailed error context
- Performance tracking for optimization
- Audit trail for all data operations
- Production-ready error reporting

**Access Logs:**
- Development: `console.log` output (real-time)
- Production: Setup log aggregation (Winston/ELK/etc.)

Your application now has enterprise-grade database operation logging! 🎉
