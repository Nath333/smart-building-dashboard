# =====================================================
# Database Migration Execution Script (PowerShell)
# Database: avancement2
# =====================================================

Write-Host "`n========================================"
Write-Host "  Database Migration - avancement2"
Write-Host "========================================`n"

# Set variables
$ProjectPath = "c:\Users\natha\Desktop\New folder (3)\SiteAutomationPlatform\database\migration"
$DatabaseName = "avancement2"
$MySQLUser = "root"
$MySQLPassword = "admin"
$MySQLPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin"  # Adjust if different

# Check if MySQL path exists, if not try to find it
if (-not (Test-Path "$MySQLPath\mysql.exe")) {
    Write-Host "[INFO] Default MySQL path not found, searching..."

    # Common MySQL installation paths
    $possiblePaths = @(
        "C:\Program Files\MySQL\MySQL Server 8.0\bin",
        "C:\Program Files\MySQL\MySQL Server 5.7\bin",
        "C:\Program Files (x86)\MySQL\MySQL Server 8.0\bin",
        "C:\Program Files (x86)\MySQL\MySQL Server 5.7\bin",
        "C:\xampp\mysql\bin",
        "C:\wamp\bin\mysql\mysql8.0.27\bin",
        "C:\wamp64\bin\mysql\mysql8.0.27\bin"
    )

    foreach ($path in $possiblePaths) {
        if (Test-Path "$path\mysql.exe") {
            $MySQLPath = $path
            Write-Host "[FOUND] MySQL at: $MySQLPath"
            break
        }
    }

    if (-not (Test-Path "$MySQLPath\mysql.exe")) {
        Write-Host "[ERROR] MySQL not found. Please update MySQLPath in this script."
        Write-Host "[INFO] Common locations:"
        Write-Host "  - C:\Program Files\MySQL\MySQL Server 8.0\bin"
        Write-Host "  - C:\xampp\mysql\bin"
        Write-Host "  - C:\wamp\bin\mysql\..."
        pause
        exit 1
    }
}

Write-Host "[INFO] Using MySQL from: $MySQLPath"

# Navigate to migration directory
Set-Location $ProjectPath
Write-Host "[INFO] Working directory: $PWD`n"

# Step 1: Backup
Write-Host "[STEP 1] Creating backup..."
$BackupFile = "backup_before_migration_$(Get-Date -Format 'yyyyMMdd_HHmmss').sql"

& "$MySQLPath\mysqldump.exe" -u $MySQLUser -p$MySQLPassword $DatabaseName > $BackupFile 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Backup failed! Check MySQL credentials and database name."
    Write-Host "[INFO] Current settings:"
    Write-Host "  User: $MySQLUser"
    Write-Host "  Password: $MySQLPassword"
    Write-Host "  Database: $DatabaseName"
    pause
    exit 1
}

Write-Host "[SUCCESS] Backup created: $BackupFile`n"

# Step 2: Create normalized tables
Write-Host "[STEP 2] Creating normalized tables..."

& "$MySQLPath\mysql.exe" -u $MySQLUser -p$MySQLPassword $DatabaseName -e "source 01_create_normalized_tables.sql" 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Table creation failed!"
    Write-Host "[INFO] You can restore from: $BackupFile"
    pause
    exit 1
}

Write-Host "[SUCCESS] Normalized tables created`n"

# Step 3: Migrate data
Write-Host "[STEP 3] Migrating data from form_sql..."

& "$MySQLPath\mysql.exe" -u $MySQLUser -p$MySQLPassword $DatabaseName -e "source 02_migrate_data.sql" 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Data migration failed!"
    Write-Host "[INFO] You can restore from: $BackupFile"
    pause
    exit 1
}

Write-Host "[SUCCESS] Data migrated successfully`n"

# Step 4: Verify
Write-Host "[STEP 4] Verifying migration..."

$VerifyQuery = @"
SELECT 'Sites:' as Table_Name, COUNT(*) as Row_Count FROM sites
UNION ALL
SELECT 'Equipment Aerotherme:', COUNT(*) FROM equipment_aerotherme
UNION ALL
SELECT 'Aerotherme Brands:', COUNT(*) FROM aerotherme_brands
UNION ALL
SELECT 'Equipment Rooftop:', COUNT(*) FROM equipment_rooftop
UNION ALL
SELECT 'Equipment Climate:', COUNT(*) FROM equipment_climate
UNION ALL
SELECT 'GTB Modules:', COUNT(*) FROM gtb_modules;
"@

& "$MySQLPath\mysql.exe" -u $MySQLUser -p$MySQLPassword $DatabaseName -e $VerifyQuery

Write-Host "`n========================================"
Write-Host "  Migration Complete!"
Write-Host "========================================`n"

Write-Host "[NEXT STEPS]"
Write-Host "1. Review output above for row counts"
Write-Host "2. Test your application"
Write-Host "3. Setup backend adapters (see API_MIGRATION.md)"
Write-Host "4. Keep backup safe: $BackupFile`n"

pause
