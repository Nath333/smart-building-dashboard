# ✅ Climate Equipment Field Mapping - Fixed

**Date:** October 14, 2025
**Status:** ✅ Verified and Fixed

---

## Summary of Changes

### 1. **Added Missing Database Columns**
```sql
ALTER TABLE equipment_climate
ADD COLUMN nb_unite_ext_clim_ir VARCHAR(50) AFTER nb_clim_ir,
ADD COLUMN nb_unite_ext_clim_wire VARCHAR(50) AFTER nb_clim_wire;
```

### 2. **Updated equipmentDAL.js**
- Added new fields to `baseFields` array in `saveClimateData()`
- Updated SQL INSERT query to include new columns
- Updated `fieldMap` in `getClimateData()` to include new fields
- Verified field name mapping between frontend and database

---

## Complete Field Mapping

### **Frontend → Database Mapping**

| Frontend Field | Database Column | Type | Status | Notes |
|----------------|-----------------|------|--------|-------|
| `nb_clim_ir` | `nb_clim_ir` | INT | ✅ Direct | Number of IR climate units |
| `nb_unite_ext_clim_ir` | `nb_unite_ext_clim_ir` | VARCHAR(50) | ✅ Direct | **NEW** - External units for IR |
| `nb_clim_wire` | `nb_clim_wire` | INT | ✅ Direct | Number of wired climate units |
| `nb_unite_ext_clim_wire` | `nb_unite_ext_clim_wire` | VARCHAR(50) | ✅ Direct | **NEW** - External units for wired |
| `coffret_clim` | `coffret_clim` | VARCHAR(255) | ✅ Direct | Control panel type |
| `type_clim` | `type_clim` | VARCHAR(255) | ✅ Direct | Climate system type |
| `Fonctionement_clim` | `fonctionement_clim` | TEXT | ✅ Mapped | Frontend uses capital F |
| `Maintenance_clim` | `maintenance_clim` | TEXT | ✅ Mapped | Frontend uses capital M |
| `nb_telecommande_clim_smartwire` | `nb_telecommande_clim_smartwire` | INT | ✅ Direct | Multi-group remotes |
| `nb_telecommande_clim_wire` | `nb_telecommande_clim_wire` | INT | ✅ Direct | Simple remotes |
| `commentaire_clim` | `commentaire_clim` | TEXT | ✅ Direct | Comments |
| `tableau_comptage_clim` | `td_clim` | VARCHAR(255) | ✅ Mapped | Frontend uses descriptive name |
| `clim_ir_ref_0` ... `clim_ir_ref_9` | `climate_references` | Normalized | ✅ Mapped | IR unit references |
| `clim_wire_ref_0` ... `clim_wire_ref_9` | `climate_references` | Normalized | ✅ Mapped | Wired unit references |
| `zone_clim` | `zone_clim` | VARCHAR(255) | ✅ Direct | Zone identifier (multi-zone support) |

---

## Field Mappings in equipmentDAL.js

### **getClimateData() - Line 484-497**
```javascript
const fieldMap = {
  nb_clim_ir: 'nb_clim_ir',
  nb_unite_ext_clim_ir: 'nb_unite_ext_clim_ir',           // ✅ NEW
  nb_clim_wire: 'nb_clim_wire',
  nb_unite_ext_clim_wire: 'nb_unite_ext_clim_wire',       // ✅ NEW
  coffret_clim: 'coffret_clim',
  type_clim: 'type_clim',
  fonctionement_clim: 'Fonctionement_clim',               // ⚠️ Mapped (case change)
  maintenance_clim: 'Maintenance_clim',                   // ⚠️ Mapped (case change)
  nb_telecommande_clim_smartwire: 'nb_telecommande_clim_smartwire',
  nb_telecommande_clim_wire: 'nb_telecommande_clim_wire',
  commentaire_clim: 'commentaire_clim',
  td_clim: 'tableau_comptage_clim'                        // ⚠️ Mapped (name change)
};
```

### **saveClimateData() - Line 525-538**
```javascript
const baseFields = [
  'nb_clim_ir',
  'nb_unite_ext_clim_ir',           // ✅ NEW
  'nb_clim_wire',
  'nb_unite_ext_clim_wire',         // ✅ NEW
  'coffret_clim',
  'type_clim',
  'Fonctionement_clim',             // Frontend field name (capital F)
  'Maintenance_clim',               // Frontend field name (capital M)
  'nb_telecommande_clim_smartwire',
  'nb_telecommande_clim_wire',
  'commentaire_clim',
  'tableau_comptage_clim'           // Frontend field name
];
```

---

## Database Schema (equipment_climate)

```sql
CREATE TABLE equipment_climate (
  id INT PRIMARY KEY AUTO_INCREMENT,
  site_name VARCHAR(100) NOT NULL,
  zone_clim VARCHAR(255),

  -- Climate units
  nb_clim_ir INT,
  nb_unite_ext_clim_ir VARCHAR(50),          -- ✅ NEW
  nb_clim_wire INT,
  nb_unite_ext_clim_wire VARCHAR(50),        -- ✅ NEW

  -- Configuration
  coffret_clim VARCHAR(255),
  type_clim VARCHAR(255),
  fonctionement_clim TEXT,
  maintenance_clim TEXT,

  -- Remote controls
  nb_telecommande_clim_smartwire INT,
  nb_telecommande_clim_wire INT,

  -- Additional info
  commentaire_clim TEXT,
  td_clim VARCHAR(255),                      -- Maps to tableau_comptage_clim

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (site_name) REFERENCES sites(site_name) ON DELETE CASCADE,
  INDEX idx_site (site_name)
);
```

---

## Reference Table Schema (climate_references)

```sql
CREATE TABLE climate_references (
  id INT PRIMARY KEY AUTO_INCREMENT,
  site_name VARCHAR(100) NOT NULL,
  zone_clim VARCHAR(50),                     -- For multi-zone support
  ref_type ENUM('clim_ir', 'clim_wire') NOT NULL,
  ref_index INT,                             -- 0-9 (or more)
  ref_value VARCHAR(255),                    -- Brand/model reference

  FOREIGN KEY (site_name) REFERENCES sites(site_name) ON DELETE CASCADE,
  INDEX idx_site (site_name),
  INDEX idx_type (ref_type),
  UNIQUE KEY unique_site_ref (site_name, zone_clim, ref_type, ref_index)
);
```

---

## Frontend Component (categoryInputConfig.jsx)

### **Climate Category Fields - Lines 152-219**

```javascript
case 'Clim':
  return (
    <>
      {numberInput('Nombre de clims (IR)', 'nb_clim_ir')}
      {selectInput("Nombre d'unités extérieures pour les clims IR", 'nb_unite_ext_clim_ir', [...])}

      {numberInput('Nombre de clims (filaires)', 'nb_clim_wire')}
      {selectInput("Nombre d'unités extérieures pour les clims filaires", 'nb_unite_ext_clim_wire', [...])}

      {numberInput('Nombre de télécommandes simples', 'nb_telecommande_clim_wire')}
      {selectInput('Télécommande déportée intelligente', 'coffret_clim', [...])}
      {numberInput('Nombre de télécommandes multi-groupe', 'nb_telecommande_clim_smartwire')}

      {selectInput('Type de fonctionnement', 'type_clim', [...], true)}
      {selectInput('Dans quel tableau se trouve le comptage clim ?', 'tableau_comptage_clim', [...])}

      {renderMarqueInputs(categoryData['nb_clim_ir'], 'clim_ir_ref', categoryData, handleCategoryDataChange)}
      {renderMarqueInputs(categoryData['nb_clim_wire'], 'clim_wire_ref', categoryData, handleCategoryDataChange)}

      {textInput('Est-ce que tous fonctionnent ?', 'Fonctionement_clim')}
      {textInput('Maintenance', 'Maintenance_clim')}
      {textInput('Commentaire', 'commentaire_clim')}
    </>
  );
```

---

## Data Flow Example

### **Save Operation:**
```
Frontend (categoryInputConfig.jsx)
↓
categoryData = {
  nb_clim_ir: 4,
  nb_unite_ext_clim_ir: "2",
  clim_ir_ref_0: "Daikin Model A",
  clim_ir_ref_1: "Daikin Model B",
  ...
  Fonctionement_clim: "All working",
  tableau_comptage_clim: "TGBT"
}
↓
POST /save_page2
↓
formSqlAdapter.saveToBothStructures()
↓
equipmentDAL.saveClimateData()
↓
Database:
  equipment_climate: {
    nb_clim_ir: 4,
    nb_unite_ext_clim_ir: "2",
    fonctionement_clim: "All working",
    td_clim: "TGBT"
  }
  climate_references: [
    { ref_type: 'clim_ir', ref_index: 0, ref_value: 'Daikin Model A' },
    { ref_type: 'clim_ir', ref_index: 1, ref_value: 'Daikin Model B' }
  ]
```

### **Load Operation:**
```
POST /get-page2
↓
formSqlAdapter.convertToFlatStructure()
↓
equipmentDAL.getClimateData()
↓
Database Query:
  SELECT * FROM equipment_climate WHERE site_name = ?
  SELECT * FROM climate_references WHERE site_name = ?
↓
Field Mapping (via fieldMap):
  fonctionement_clim → Fonctionement_clim
  maintenance_clim → Maintenance_clim
  td_clim → tableau_comptage_clim
↓
Flattened Response:
{
  nb_clim_ir: 4,
  nb_unite_ext_clim_ir: "2",
  clim_ir_ref_0: "Daikin Model A",
  clim_ir_ref_1: "Daikin Model B",
  Fonctionement_clim: "All working",
  tableau_comptage_clim: "TGBT"
}
↓
Frontend receives data in expected format
```

---

## Testing Checklist

- [x] Database columns added successfully
- [x] equipmentDAL.js updated with new fields
- [x] Field mapping verified in getClimateData()
- [x] Field mapping verified in saveClimateData()
- [ ] Test save operation with all fields
- [ ] Test load operation with all fields
- [ ] Verify references are saved correctly
- [ ] Verify references are loaded correctly
- [ ] Test multi-zone support
- [ ] Test with empty/null values

---

## Related Files

- **Frontend**: [categoryInputConfig.jsx](../src/pages/equipment/categoryInputConfig.jsx:152-219)
- **Data Access**: [equipmentDAL.js](dal/equipmentDAL.js:460-614)
- **Adapter**: [formSqlAdapter.js](adapters/formSqlAdapter.js)
- **Server**: [server.js](../server.js:200-231, 235-249)

---

## Important Notes

1. **Case Sensitivity**: Frontend uses `Fonctionement_clim` (capital F) and `Maintenance_clim` (capital M), while database uses lowercase
2. **Field Name Difference**: Frontend uses `tableau_comptage_clim` while database uses `td_clim`
3. **New Fields**: `nb_unite_ext_clim_ir` and `nb_unite_ext_clim_wire` are new additions to support external unit tracking
4. **Normalized References**: Individual unit references (clim_ir_ref_0, etc.) are stored in the separate `climate_references` table
5. **Multi-Zone Support**: The schema supports multiple zones per site via the `zone_clim` column

---

**Status**: ✅ All field mappings verified and database schema updated
**Next Step**: Test save/load operations with real data
